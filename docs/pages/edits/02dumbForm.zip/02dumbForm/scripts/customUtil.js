console.log("found customUtil");

let currentShader="off";


/* _______________________ Event Helpers ______________________________*/
function addDiagBox(click){
    if(viewerGetCurrentSet()==2){
        let a=click.split(',');
        addInput(       "pTral2"+click,
                        "pTrial2Diag",
                        "Diagnosis",
                        "pTrial2DiagElems",
                        "highlightClick("+a[0]+","+a[1]+", "+a[2]+", "+a[3]+", \""+currentShader+"\");useWASD=false;",
                        "",
                        "useWASD=true;");
    }
}
function removeDiagBox(click){
    if(viewerGetCurrentSet()==2){
        removeElement("pTral2"+click);
    }
}


/* _______________________ Form Helpers ______________________________*/

function addInput(elemID, toID, hint="", className="", onfocus="", oninput="", onblur="") {
    let text = document.createElement('div');
    text.id = elemID;
    text.style.padding="2px";
    text.innerHTML = "<input type='text' style='width:90%;' class='"+className+"' placeholder='"+hint+"' onfocus='"+onfocus+"' onclick='"+onfocus+"' oninput='"+oninput+"' onblur='"+onblur+"'/>";

    $(toID).appendChild(text);
}

function removeElement(elemID){
    let e=$(elemID)
    e.parentNode.removeChild(e);
}


function highlightClick(at,x,y,z,shaderName=""){
    if(shaderName!=""){
        if(applyShader(shaderName))
            viewerLogShaderMessage("auto change to "+shaderName);
    }
    viewerResetHighlights(at);
    viewerAddHighlight(at,x,y,z);
    viewerLogScrollMessage(at,'auto scroll to '+z);
    viewerSetSlide(at,z);
}

/* _______________________ State Helpers ______________________________*/
function applyShader(shaderName){
    if(currentShader==shaderName)
        return false;

    $('pTrial2windowing').value=shaderName;
    viewerSetShader(shaderName);
    currentShader=shaderName;
    return true;
}