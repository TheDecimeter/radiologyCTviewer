console.log("found custom init");

let initiatedShadersOnce = false;
function initCustom(){
    if(initiatedShadersOnce)
        return;
    initiatedShadersOnce=true;

    /* common windowing levels according to values on microdicom
    Note that very small windows will amplify jpg's compression defects*/
    viewerAddWindowingShaderGray('skull',.5125,.0475,false);
    viewerAddWindowingShaderGray('lung',.3,.8,false);
    viewerAddWindowingShaderGray('ab',.505,.2,false);
    viewerAddWindowingShaderGray('mediastinum',.505,.225,false);
    viewerAddWindowingShaderGray('bone',.65,1.25,false);
    viewerAddWindowingShaderGray('spine',.51,.15,false);
    viewerAddWindowingShaderGray('postmyelo',.6,.5,false);
    viewerAddWindowingShaderGray('felsenbein',.75,2,false);
    viewerAddWindowingShaderGray('user1',.5,-1,false);

    //instead of logging the creation of each message to send back to the server, just make an initial statement with and ID to easily find what the shaders were.
    viewerLogShaderMessage("added initial 4JUN2020");
}
