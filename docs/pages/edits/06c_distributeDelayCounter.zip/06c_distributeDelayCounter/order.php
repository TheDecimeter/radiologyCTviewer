<?php

$fName = "use.txt";
$fReader = fopen($fName,"r+");
if($fReader && flock($fReader, LOCK_EX|LOCK_NB)){
        $fContent = fread($fReader, filesize($fName));
        $orderType = intval($fContent);
        $version=$fContent;

        $nextOrder=$orderType+1;
        if($nextOrder>1)
                $nextOrder=0;
        
        $fContent=strval($nextOrder);
        rewind($fReader);
        if(strlen($fContent)<2)
                fwrite($fReader,"0");
        fwrite($fReader,$fContent);
        flock($fReader,LOCK_UN);
}
else{
        $orderType=-1;
        $version="x";
}


switch($orderType){
       default:
            $order=[];
       break;
       case 0:
            $order=[1,0];
       break;
       case 1:
            $order=[0,1];
       break;
}

$response= array("version"=>$version,"order"=>$order);
echo json_encode($response);

?>