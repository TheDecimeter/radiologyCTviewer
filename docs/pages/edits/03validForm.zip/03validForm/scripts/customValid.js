console.log("found customValid");

//CONSENT
function validConsent(){
    let allGood=true;
    if(!isChecked("pConsentContinue",1,2))
        allGood=false;

    err(!allGood,"pConsentErr");
    return allGood;
}



//DEMOGRAPHICS
let pDemographicsChecked=false;
function recheckDemographics(){
    if(!pDemographicsChecked)
        return;
    validDemographics();
}
function validDemographics(){
    pDemographicsChecked=true;
    let allGood=true;

    //AGE
    if(!isNum("pDemographicsAgeField"))
        allGood=false;

    //GENDER
    if(!isChecked("pDemographicsGender",1,3))
        allGood=false;
    if(!isValidOther('pDemographicsGender3','pDemographicsGenderOtherTxt'))
        allGood=false;

    //CERTIFICATION
    if(!isChecked("pDemographicsCert",1,2))
        allGood=false;

    //EXPERTISE
    if(!isChecked("pDemographicsExp",1,6))
        allGood=false;
    if(!isValidOther('pDemographicsExp5','pDemographicsExpOtherTxt'))
        allGood=false;


    err(!allGood,"pDemographicsErr");
    return allGood;
}


//TRIAL 1
let pTrial1Checked=false;
function recheckTrial1(){
    if(!pTrial1Checked)
        return;
    validTrial1();
}
function validTrial1(){
    pTrial1Checked=true;
    let allGood=true;

    //check form errors
    //CHECK BOXES
    if(!isChecked("pTrial1Abnorm",1,5))
        allGood=false;
    if(!isValidOther('pTrial1Abnorm4','pTrial1AbnormOtherTxt'))
        allGood=false;

    //show form errors
    err(!allGood,"pTrial1Err");

    //check for scrolling
    if(!userScrolled){
        allGood=false;
        err(true,"pTrial1Scrl");
    }

    //gatekeeper depends on scrolling and form errors
    return allGood;
}


//TRIAL 2
let pTrial2Checked=false;
function recheckTrial2(){
    if(!pTrial2Checked)
        return;
    validTrial2();
}
function validTrial2(){
    pTrial2Checked=true;
    let allGood=true;
    let clicks=userClickedTrial2 != 0;

    //selected both options
    if(clicks && $('pTrial2NoneFound').checked){
        allGood=false;
        err(true,"pTrial2DoubleErr");
    }
    else
        err(false,"pTrial2DoubleErr");


    //selected no options
    if(!clicks && !$('pTrial2NoneFound').checked){
        allGood=false;
        err(true,"pTrial2NoneErr");
    }
    else
        err(false,"pTrial2NoneErr");

    //check that any diagnosis boxes are filled
    if(!checkInFilled("pTrial2Diag","pTrial2DiagElems")){
        allGood=false;
        err(true,"pTrial2DiagErr");
    }
    else
        err(false,"pTrial2DiagErr");


    err(!allGood,"pTrial2Err")

    //check for scrolling
    if(!userScrolled){
        allGood=false;
        err(true,"pTrial2Scrl");
    }

    //gatekeeper depends on scrolling and form errors
    return allGood;
}








/* _______________________ Helpers ______________________________*/


function checkInFilled(at, className,showError=true){
    at=$(at);
    if(at==null){
        console.log("at is null");
        return true;
    }
        
    let l=at.querySelectorAll('.'+className);
    let allGood=true;
    for(let i=0; i<l.length; ++i)
        if(!isFilled(l[i],showError)){
            allGood=false;
        }
    return allGood;
}