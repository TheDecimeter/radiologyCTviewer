console.log("found custom valid");

function validConsent(){
    let allGood = true;
    if(!isChecked("pConsentContinue",1,2))
        allGood=false;

    err(!allGood,"pConsentErr");
    return allGood;
}

//Demographics
let pDemographicsChecked=false;
function recheckDemographics(){
    if(!pDemographicsChecked)
        return;
    validDemographics();
}
function validDemographics(){
    pDemographicsChecked=true;
    let allGood=true;

    //age
    if(!isNum("pDemographicsAgeField"))
        allGood=false;

    //gender
    if(!isChecked("pDemographicsGender",1,3))
        allGood=false;
    if(!isValidOther('pDemographicsGender3','pDemographicsGenderOtherTxt'))
        allGood=false;

    //cert
    if(!isChecked("pDemographicsCert",1,2))
        allGood=false;
    //exp
    if(!isChecked("pDemographicsExp",1,6))
        allGood=false;
    if(!isValidOther('pDemographicsExp5','pDemographicsExpOtherTxt'))
        allGood=false;


    err(!allGood,"pDemographicsErr");

    return allGood;
}


//Trial1
let pTrial1Checked=false;
function recheckTrial1(){
    if(!pTrial1Checked)
        return;
    validTrial1();
}
function validTrial1(){
    pTrial1Checked=true;
    let allGood=true;

    if(!isChecked("pTrial1abnorm",1,5))
        allGood=false;
    if(!isValidOther('pTrial1abnorm4','pTrial1abnormOtherTxt'))
        allGood=false;

    err(!allGood,"pTrial1Err");

    if(!userScrolled){
        allGood=false;
        err(true,"pTrial1Scrl");
    }

    return allGood;
}


//Trial2
let pTrial2Checked=false;
function recheckTrial2(){
    if(!pTrial2Checked)
        return;
    validTrial2();
}
function validTrial2(){
    pTrial2Checked=true;
    let allGood=true;

    let clicks = userClickedTrial2 != 0;

    //both
    if(clicks && $('pTrial2NoneFound').checked){
        allGood=false;
        err(true,"pTrial2DoubleErr");
    }
    else
        err(false,"pTrial2DoubleErr");

    //none
    if(!clicks && !$('pTrial2NoneFound').checked){
        allGood=false;
        err(true,"pTrial2NoneErr");
    }
    else
        err(false,"pTrial2NoneErr");

    //no diagnosis
    if(!checkInFilled("pTrial2Diag","pTrial2DiagElems")){
        allGood=false;
        err(true,"pTrial2DiagErr");
    }
    else
        err(false,"pTrial2DiagErr");


    err(!allGood,"pTrial2Err");

    if(!userScrolled){
        allGood=false;
        err(true,"pTrial2Scrl");
    }

    return allGood;
}




//HELPERS
function checkInFilled(at, className,showError=true){
    at=$(at);
    if(at==null){
        console.log("at is null");
        return true;
    }
        
    let l=at.querySelectorAll('.'+className);
    let allGood=true;
    for(let i=0; i<l.length; ++i)
        if(!isFilled(l[i],showError)){
            allGood=false;
        }
    return allGood;
}