<!DOCTYPE html>
<html>
       <head>
              <title>ct-viewer</title>
    	      <link rel="shortcut icon" href="favicon.ico">
              <meta name="robots" content="noindex">
              <meta http-equiv="content-type" content="text/html; charset=UTF-8">
              <meta id="gameViewport" name="viewport" content="width=device-width initial-scale=1">
              <link href="styles.css" rel="stylesheet" type="text/css">
              <script src="soundmanager2-setup.js"></script>
  		<script src="soundmanager2-jsmin.js"></script>

              <!--classes-->
  		<script src="scripts/stack.js"></script>
  		<script src="scripts/firework.js"></script>
  		<script src="scripts/ruler.js"></script>

              <!--other scripts and functions and whatnot-->
  		<script src="scripts/common.js"></script>
  		<script src="scripts/viewerEvents.js"></script>
  		<script src="scripts/customInit.js"></script>
  		<script src="scripts/customUtil.js"></script>
  		<script src="scripts/customValid.js"></script>
  		<script src="scripts/trialOrder.js"></script>

       </head>

       <body>
              <!--This won't show if javascript is enabled -->
              <noscript style="font-size: 300%;">Please Enable JavaScript for this page to work.<br><a href="https://www.enable-javascript.com/">Click here to learn how.</a></noscript>

              <table> 
                     <tr><td rowspan="3" id="sidePadding"></td></tr><!--some reason the usual centering method wasn't working so this is expanded as needed at load time-->
                     <tr>
                            <td>
                                   <table>
                                          <tr>
                                                 <td>
                                                        <div class="center" id='feedbackConsole'></div>
                                                 </td>
                                                 <td>
                                                        <div class="center" id='stageCounter'></div>
                                                 </td>
                                          </tr>
                                   </table>
                            </td>
                     </tr>
                     <tr>
                            <td>
                                   <table>
                                          <tr>
                                                 <td>
                                                        <div id="viewerWindow" style="display:none;">
                                                               <div id="embed-html"></div><!--viewer area-->
                                                               <script type="text/javascript" src="html/html.nocache.js"></script>
                                                        </div>
                                                 </td>
                                                 <td class="formOuter">
                                                        <div id="formDiv" class="formHousing"><!--question area-->
                                                               
                                                               <form id="questions" action="p.php" method="post"><!-- "p.php" doesn't exist, if using a third party solution for getting your data, replace "p.php" with their destination, if following my tutorials, ignore this-->

                                                                      <!--INTRO PAGE -->
                                                                      <div id="pIntro"    style="display:block;" class="formPage">
                                                                             <button onclick="trialOrder.startNext();" type="button">Show<br>viewer</button><br>
                                                                             <br>
                                                                             Hidy There
                                                                             
                                                                             <table style="width:99%"><tr><td style="width:99%"></td><td><button class="arrowFont" onclick="goToPage('pConsent');advanceCounter();" type="button">&rarr;</button></td></tr></table>
                                                                      </div>
                                                                      <!--CONSENT PAGE -->
                                                                      <div id="pConsent"    class="formPage">
                                                                             <br>
                                                                             Consent page
                                                                             <br><br><br>

                                                                             <div id="pConsentContinue" oninput="validConsent();" class="formQst" style="margin-left: 3em;">
                                                                                    <b>Would you like to continue?</b><br>
                                                                                    <span id="pConsentContinueShuffle"><!--Anything in here can get shuffled-->
                                                                                           <span class="formRadio">
                                                                                                  <label>
                                                                                                         <input type="radio"  id="pConsentContinue1" name="pConsentContinue" value="Yes">
                                                                                                         Yes
                                                                                                  </label><br>
                                                                                           </span>
                                                                                           <span class="formRadio">
                                                                                                  <label>
                                                                                                         <input type="radio" id="pConsentContinue2" name="pConsentContinue" value="No">
                                                                                                         No
                                                                                                  </label><br>
                                                                                           </span>
                                                                                    </span>
                                                                             </div>
                                                                             <br><br><br><br>

                                                                             <div id="pConsentErr" class="errorMsg">
                                                                                    Please Check Highlighted Field.
                                                                             </div>
                                                                             <br>                                                                             
                                                                             <table style="width:99%"><tr><td style="width:99%"></td><td><button class="arrowFont" onclick="if(validConsent())consentBranch();" type="button">&rarr;</button></td></tr></table>
                                                                      </div>
                                                                      <!--THANKS PAGE -->
                                                                      <div id="pThanks"    class="formPage">
                                                                             Thank you for your time.
                                                                      </div>
                                                                      <!--INSTRUCTION PAGE -->
                                                                      <div id="pInstruction"    class="formPage">
                                                                             There will be a viewer, you can scroll on the images with keyboard or mouse.
                                                                             <br><br>
                                                                             Please answer the following questions to the best of your ability.
                                                                             <table style="width:99%"><tr><td style="width:99%"></td><td><button class="arrowFont" onclick="goToPage('pDemographics');advanceCounter();" type="button">&rarr;</button></td></tr></table>
                                                                      </div>



                                                                      <!--DEMOGRAPHICS PAGE -->
                                                                      <div id="pDemographics"    class="formPage" oninput="recheckDemographics();">
                                                                             <h2>Demographics</h2>
                                                                             <br><br>
                                                                             <div id="pDemographicsAge" class="formQst">
                                                                                    <b>What is your age (in years)?</b><br>
                                                                                    <input type="number" min="1" max="150" id="pDemographicsAgeField" name="pDemographicsAge" oninput="isNum(this);">
                                                                             </div>
                                                                             <br><br><br><br>

                                                                             <div id="pDemographicsGender" oninput="isChecked(this,1,3);" class="formQst">
                                                                                    <b>What is your gender?</b><br>
                                                                                    <span id="pDemographicsGenderShuffle"><!--Anything in here can get shuffled-->
                                                                                           <span class="formRadio">
                                                                                                  <label>
                                                                                                         <input type="radio"  id="pDemographicsGender1" name="pDemographicsGender" value="Female">
                                                                                                         Female
                                                                                                  </label><br>
                                                                                           </span>
                                                                                           <span class="formRadio">
                                                                                                  <label>
                                                                                                         <input type="radio" id="pDemographicsGender2" name="pDemographicsGender" value="Male">
                                                                                                         Male
                                                                                                  </label><br>
                                                                                           </span>
                                                                                    </span>
                                                                                    <span class="formRadio">
                                                                                           <label>
                                                                                                  <input type="radio" id="pDemographicsGender3" name="pDemographicsGender" value="Other">
                                                                                                  Other
                                                                                           </label>
                                                                                           <input type="text" id="pDemographicsGenderOtherTxt" name="pDemographicsGenderOtherTxt" 
                                                                                                                oninput="updateCheckOther(this,'pDemographicsGender3');isValidOther('pDemographicsGender3','pDemographicsGenderOtherTxt');"
                                                                                                                onfocus="useWASD=false;"
                                                                                                                onblur="useWASD=true;">
                                                                                    </span><br>
                                                                             </div>
                                                                             <br><br><br><br>

                                                                             <div id="pDemographicsCert" oninput="isChecked(this,1,2);" class="formQst">
                                                                                    <b>What is your gender?</b><br>
                                                                                    <span id="pDemographicsCertShuffle"><!--Anything in here can get shuffled-->
                                                                                           <span class="formRadio">
                                                                                                  <label>
                                                                                                         <input type="radio"  id="pDemographicsCert1" name="pDemographicsCert" value="Yes">
                                                                                                         Yes
                                                                                                  </label><br>
                                                                                           </span>
                                                                                           <span class="formRadio">
                                                                                                  <label>
                                                                                                         <input type="radio" id="pDemographicsCert2" name="pDemographicsCert" value="No">
                                                                                                         No
                                                                                                  </label><br>
                                                                                           </span>
                                                                                    </span>
                                                                             </div>
                                                                             <br><br><br><br>

                                                                             <div id="pDemographicsExp" oninput="isChecked(this,1,6);" class="formQst">
                                                                                    <div style="line-height:1.2em;">
                                                                                           <b>What is your area of expertise: (check all that apply)</b><br>
                                                                                    </div>
                                                                                    <span id="pDemographicsExpShuffle"><!--Anything in here can get shuffled-->
                                                                                           <span class="formCheckBox">
                                                                                                  <label> 
                                                                                                         <input type="checkbox" id="pDemographicsExp1" name="pDemographicsExp1" value="Lung" onclick="clearChecks('pDemographicsExp',6,6);isValidOther('pDemographicsExp5','pDemographicsExpOtherTxt');">
                                                                                                         Lung
                                                                                                         <span class="checkmark"> </span>
                                                                                                  </label><br>
                                                                                           </span>
                                                                                           <span class="formCheckBox">
                                                                                                  <label> 
                                                                                                         <input type="checkbox" id="pDemographicsExp2" name="pDemographicsExp2" value="Nuclear" onclick="clearChecks('pDemographicsExp',6,6);isValidOther('pDemographicsExp5','pDemographicsExpOtherTxt');">
                                                                                                         Nuclear
                                                                                                         <span class="checkmark"> </span>
                                                                                                  </label><br>
                                                                                           </span>
                                                                                           <span class="formCheckBox">
                                                                                                  <label> 
                                                                                                         <input type="checkbox" id="pDemographicsExp3" name="pDemographicsExp3" value="Bone" onclick="clearChecks('pDemographicsExp',6,6);isValidOther('pDemographicsExp5','pDemographicsExpOtherTxt');">
                                                                                                         Bone
                                                                                                         <span class="checkmark"> </span>
                                                                                                  </label><br>
                                                                                           </span>
                                                                                           <span class="formCheckBox">
                                                                                                  <label> 
                                                                                                         <input type="checkbox" id="pDemographicsExp4" name="pDemographicsExp4" value="Skin" onclick="clearChecks('pDemographicsExp',6,6);isValidOther('pDemographicsExp5','pDemographicsExpOtherTxt');">
                                                                                                         Skin
                                                                                                         <span class="checkmark"> </span>
                                                                                                  </label><br>
                                                                                           </span>
                                                                                    </span><!--Anything out of here can't get shuffled-->
                                                                                    <span>
                                                                                           <span id="pDemographicsExpOtherUnspecified" class="errorMsg">
                                                                                                  Custom Other Unspecified Error Message <br>
                                                                                           </span>
                                                                                           <span id="pDemographicsExpOther" class="formCheckBox">
                                                                                                         <label> 
                                                                                                                <input type="checkbox" id="pDemographicsExp5" name="pDemographicsExp5" value="Other"onclick="clearChecks('pDemographicsExp',6,6);isValidOther('pDemographicsExp5','pDemographicsExpOtherTxt',false);">
                                                                                                                Other
                                                                                                                <span class="checkmark"></span>
                                                                                                         </label>
                                                                             
                                                                                                         <input type="text" id="pDemographicsExpOtherTxt" name="pDemographicsExpOtherTxt" 
                                                                                                                oninput="if(updateCheckOther(this,'pDemographicsExp5'))clearChecks('pDemographicsExp',6,6);isValidOther('pDemographicsExp5','pDemographicsExpOtherTxt');"
                                                                                                                onfocus="useWASD=false;"
                                                                                                                onblur="useWASD=true;">
                                                                                           </span><br>
                                                                                    </span>
                                                                                    <span class="formCheckBox">
                                                                                           <label> 
                                                                                                  <input type="checkbox" id="pDemographicsExp6" name="pDemographicsExp6" value="None" onclick="clearChecks('pDemographicsExp',1,5);">
                                                                                                  None
                                                                                                  <span class="checkmark"> </span>
                                                                                           </label>
                                                                                    </span>
                                                                             </div>
                                                                             <br><br><br><br>




                                                                             <div id="pDemographicsErr" class="errorMsg">
                                                                                    Please Check Highlighted Fields.
                                                                             </div>
                                                                             <br> 
                                                                             <table style="width:99%"><tr><td style="width:99%"></td><td><button class="arrowFont" onclick="if(validDemographics())trialOrder.startNext();" type="button">&rarr;</button></td></tr></table>
                                                                      </div>
                                                                      <!--Trial1 PAGE -->
                                                                      <div id="pTrial1"    class="formPage">
                                                                             <h2>Trial1</h2>
                                                                             <br><br>

                                                                             <div id="pTrial1abnorm" oninput="recheckTrial1();" class="formQst">
                                                                                    <div style="line-height:1.2em;">
                                                                                           <b>Indicate any abnormalities: (check all that apply)</b><br>
                                                                                    </div>
                                                                                    <span id="pTrial1abnormShuffle"><!--Anything in here can get shuffled-->
                                                                                           <span class="formCheckBox">
                                                                                                  <label> 
                                                                                                         <input type="checkbox" id="pTrial1abnorm1" name="pTrial1abnorm1" value="Lung Nodules" onclick="clearChecks('pTrial1abnorm',5,5);isValidOther('pTrial1abnorm4','pTrial1abnormOtherTxt');">
                                                                                                         Lung Nodule(s)
                                                                                                         <span class="checkmark"> </span>
                                                                                                  </label><br>
                                                                                           </span>
                                                                                           <span class="formCheckBox">
                                                                                                  <label> 
                                                                                                         <input type="checkbox" id="pTrial1abnorm2" name="pTrial1abnorm2" value="Broken Bone" onclick="clearChecks('pTrial1abnorm',5,5);isValidOther('pTrial1abnorm4','pTrial1abnormOtherTxt');">
                                                                                                         Broken Bone
                                                                                                         <span class="checkmark"> </span>
                                                                                                  </label><br>
                                                                                           </span>
                                                                                           <span class="formCheckBox">
                                                                                                  <label> 
                                                                                                         <input type="checkbox" id="pTrial1abnorm3" name="pTrial1abnorm3" value="Breast Cancer" onclick="clearChecks('pTrial1abnorm',5,5);isValidOther('pTrial1abnorm4','pTrial1abnormOtherTxt');">
                                                                                                         Breast Cancer
                                                                                                         <span class="checkmark"> </span>
                                                                                                  </label><br>
                                                                                           </span>
                                                                                    </span><!--Anything out of here can't get shuffled-->
                                                                                    <span>
                                                                                           <span id="pTrial1abnormOtherUnspecified" class="errorMsg">
                                                                                                  Custom Other Unspecified Error Message <br>
                                                                                           </span>
                                                                                           <span id="pTrial1abnormOther" class="formCheckBox">
                                                                                                         <label> 
                                                                                                                <input type="checkbox" id="pTrial1abnorm4" name="pTrial1abnorm4" value="Other"onclick="clearChecks('pTrial1abnorm',5,5);isValidOther('pTrial1abnorm4','pTrial1abnormOtherTxt',false);">
                                                                                                                Other
                                                                                                                <span class="checkmark"></span>
                                                                                                         </label>
                                                                                
                                                                                                         <input type="text" id="pTrial1abnormOtherTxt" name="pTrial1abnormOtherTxt" 
                                                                                                                oninput="if(updateCheckOther(this,'pTrial1abnorm4'))clearChecks('pTrial1abnorm',5,5);isValidOther('pTrial1abnorm4','pTrial1abnormOtherTxt');"
                                                                                                                onfocus="useWASD=false;"
                                                                                                                onblur="useWASD=true;">
                                                                                           </span><br>
                                                                                    </span>
                                                                                    <span class="formCheckBox">
                                                                                           <label> 
                                                                                                  <input type="checkbox" id="pTrial1abnorm5" name="pTrial1abnorm5" value="None" onclick="clearChecks('pTrial1abnorm',1,4);">
                                                                                                  None
                                                                                                  <span class="checkmark"> </span>
                                                                                           </label>
                                                                                    </span>
                                                                             </div>
                                                                             <script>shuffleInputs('pTrial1abnormShuffle');</script>
                                                                             <br><br><br><br>



                                                                             <div id="pTrial1Scrl" class="directionMsg">
                                                                                    You can use the scroll wheel, keyboard, or drag over the image to scroll through it.
                                                                             </div>
                                                                             <div id="pTrial1Err" class="errorMsg">
                                                                                    Please Check Highlighted Field.
                                                                             </div>
                                                                             <br> 
                                                                             <table style="width:99%"><tr><td style="width:99%"></td><td><button class="arrowFont" onclick="if(validTrial1()){goToPage('pTrial1End');hideViewer();trialOrder.end();}" type="button">&rarr;</button></td></tr></table>
                                                                      </div>
                                                                      <!--Trial1 END PAGE -->
                                                                      <div id="pTrial1End"    class="formPage">
                                                                             <span id="pTrial1EndMessage"></span>
                                                                             
                                                                             <table style="width:99%"><tr><td style="width:99%"></td><td><button class="arrowFont" onclick="trialOrder.startNext();" type="button">&rarr;</button></td></tr></table>
                                                                      </div>
                                                                      <!--Trial2 PAGE -->
                                                                      <div id="pTrial2"    class="formPage" oninput="recheckTrial2();">
                                                                             <h2>Trial2</h2>
                                                                             <br>
                                                                             <label>Windowing:
                                                                                    <select id="pTrial2windowing" oninput="applyShader(this.value);">
                                                                                           <optgroup label="Common">
                                                                                                  <option value="ab">Abdomen</option>
                                                                                                  <option value="bone">Bone</option>
                                                                                                  <option value="felsenbein">Felsenbein</option>
                                                                                                  <option value="lung">Lung</option>
                                                                                                  <option value="mediastinum">Mediastinum</option>
                                                                                                  <option value="postmyelo">Post Myelogram</option>
                                                                                                  <option value="skull">Skull</option>
                                                                                           </optgroup>
                                                                                           <optgroup label="Other">
                                                                                                  <option value="off" selected="selected">None</option>
                                                                                           </optgroup>
                                                                                    </select> 
                                                                             </label>
                                                                             <br><br><br><br>

                                                                             <div class="formQst">
                                                                                    Click on any abnormalities in the image
                                                                                    <br>
                                                                                    <b>or</b>
                                                                                    <br>
                                                                                    Select 
                                                                                    <span class="formCheckBox">
                                                                                           <label> 
                                                                                                  <input type="checkbox" id="pTrial2NoneFound" name="pTrial2NoneFound" value="NoneFound">
                                                                                                  None Found
                                                                                                  <span class="checkmark"> </span>
                                                                                           </label>
                                                                                    </span>
                                                                             </div>
                                                                             <br>

                                                                             <div id="pTrial2Diag"></div>

                                                                             <div id="pTrial2Scrl" class="directionMsg">
                                                                                    You can use the scroll wheel, keyboard, or drag over the image to scroll through it.
                                                                             </div>
                                                                             <div id="pTrial2DiagErr" class="errorMsg">
                                                                                    Please add a diagnosis for each click.
                                                                             </div>
                                                                             <div id="pTrial2DoubleErr" class="errorMsg">
                                                                                    You can't select <q>None Found</q> above
                                                                                    while also having tumors highlighted in the image.
                                                                             </div>
                                                                             <div id="pTrial2NoneErr" class="errorMsg">
                                                                                    You must either check <q>None Found</q> above,
                                                                                    or click on an abnormality in the image. 
                                                                             </div>
                                                                             <div id="pTrial2Err" class="errorMsg">
                                                                                    Please Check Highlighted Fields.
                                                                             </div>
                                                                             <br> 
                                                                             <table style="width:99%"><tr><td style="width:99%"></td><td><button class="arrowFont" onclick="if(validTrial2()){goToPage('pTrial2End');hideViewer();trialOrder.end();addAll('pTrial2Diag','pTrial2Diag','pTrial2DiagElems');}" type="button">&rarr;</button></td></tr></table>
                                                                      </div>
                                                                      <!--Trial2 END PAGE -->
                                                                      <div id="pTrial2End"    class="formPage">
                                                                             <span id="pTrial2EndMessage"></span>
                                                                             
                                                                             <table style="width:99%"><tr><td style="width:99%"></td><td><button class="arrowFont" onclick="trialOrder.startNext();" type="button">&rarr;</button></td></tr></table>
                                                                      </div>
                                                                      <!--COMMENTS PAGE -->
                                                                      <div id="pComments"    class="formPage">
                                                                             Are there any comments you would like to add?
                                                                             <br><br>
                                                                             <label>
                                                                                    Comments:<br>
                                                                                    <textarea rows="10" id="pCommentsBox" name="pCommentsBox" style="width:98%" onfocus="useWASD=false;" onblur="useWASD=true;"></textarea>
                                                                             </label>
                                                                             <br><br><br><br>
                                                                             
                                                                             <table style="width:99%"><tr><td style="width:99%"></td><td><button onclick="sendData();" type="button">Submit</button></td></tr></table>
                                                                      </div>
                                                                      <!--DEBRIEF OVERVIEW PAGE -->
                                                                      <div id="pDbfMain"    class="formPage">
                                                                             <h2>Success</h2>
                                                                             <br>
                                                                             The data has been successfully submitted.
                                                                             <br><br>
                                                                             Thankyou for your participation.
                                                                             <br><br><br>
                                                                             Debrief
                                                                             <br><br>
                                                                             <span id="pDbfMsg1"></span>
                                                                             <br>
                                                                             <span id="pDbfMsg2"></span>
                                                                      </div>
                                                                      <!--DEBRIEF Trial1 PAGE -->
                                                                      <div id="pDbf1"    class="formPage">
                                                                             <button onclick="applyShader('off');goToPageWithViewer('pDbfMain',4,1);" type="button" class="arrowFont">&larr;</button>
                                                                             <br>
                                                                             There were no tumors
                                                                      </div>
                                                                      <!--DEBRIEF Trial2 PAGE -->
                                                                      <div id="pDbf2"    class="formPage">
                                                                             <button onclick="applyShader('off');goToPageWithViewer('pDbfMain',4,1);" type="button" class="arrowFont">&larr;</button>
                                                                             <br>
                                                                             There were three tumors.
                                                                             <br><br>
                                                                             <button onclick="highlightClick(2,257,226,19,'lung');" type="button">Tumor A</button><br>
                                                                             <button onclick="highlightClick(2,341,287,19,'lung');" type="button">Tumor B</button><br>
                                                                             <button onclick="highlightClick(2,580,227,22,'lung');" type="button">Tumor C</button>
                                                                      </div>

                                                                      









                                                                      <!--SUBMIT FAIL PAGE -->
                                                                      <div id="pFail"    class="formPage">
                                                                             <br><br>
                                                                             <h2>Submission Failed</h2>
                                                                             <br>
                                                                             Please <b>keep this page open to retain your data</b> and try submitting again later.
                                                                             <br><br>
                                                                             This is normally caused by a temporary interruption in the network.
                                                                             <br><br>
                                                                             Attempts: <span id="pFailAttempts"></span>
                                                                             <br><br>
                                                                             Error Code: <span id="pFailCode"></span>

                                                                             <table style="width:99%"><tr><td style="width:99%"></td><td><button onclick="sendData();" type="button">Try&nbsp;Again</button></td></tr></table>
                                                                      </div>
                                                                      <!--SUBMIT MULTIFAIL PAGE -->
                                                                      <div id="pMultiFail"    class="formPage">
                                                                             <br><br>
                                                                             <h2>Submission Failed</h2>
                                                                             <br>
                                                                             The server has consistantly failed to respond. You are welcome to keep trying, or 
                                                                             simply <span id="pMultiFailReturn">email the following data to me.</span>
                                                                             <br><br>
                                                                             Thankyou for participating, sorry for the inconvenience.
                                                                             <br><br>
                                                                             <table style="width:99%"><tr><td style="width:99%"></td><td><button onclick="sendData();" type="button">Try&nbsp;Again</button></td></tr></table>
                                                                             <br>
                                                                             <table style="width:99%"><tr><td style="width:99%"></td><td><button onclick="copyData();" type="button">Copy</button></td></tr></table>
                                                                             <label>Data:<br>
                                                                                    <textarea readonly rows="10" id="pMultiFailData" style="width:100%"></textarea>
                                                                             </label>
                                                                             <br><br>
                                                                             <!-- <span id="pMultiFailReturnFull">You may also click here to load all the data into your email client.</span> -->

                                                                             <br><br>
                                                                             Attempts: <span id="pMultiFailAttempts"></span>
                                                                             <br><br>
                                                                             Error Code: <span id="pMultiFailCode"></span>
                                                                      </div>

                                                                      <!--BLOCKER PAGE if the user needs the viewer before it is ready, this lets them know it's comming 
                                                                             also used for submitting data (If you remove this page the viewer may never load, it is
                                                                             referenced in scripts/viewerEvents.js-->
                                                                      <div id="blocker"    class="formPage">
                                                                             <span id="blockerText">Loading CT-Viewer</span>
                                                                             <br><br>
                                                                             <div id="blockerConsole"></div>
                                                                             <table><tr><td style="width:40%;"></td><td>
                                                                                    <div class="loader"></div>
                                                                             </td><td style="width:40%;"></td></tr></table>
                                                                      </div>

                                                               </form>
                                                        </div>
                                                 </td>
                                          </tr>
                                   </table>
                            </td>
                     </tr>
              </table>

       </body>

       <script>

              var trialOrder=new TrialOrder('pComments','trialOrder');
              
<?php

$v=0;
if(isset($_GET["v"]))
       $v=intval(trim($_GET["v"],"\""));


$version = "_".$v;
if($v==0 || $v > 2000){ //added ability to distribute and provide ID
       echo "console.warn('force distribute');\n";
       $files = new FilesystemIterator("data/");
       $orderType = iterator_count($files) % 2;
       $version .= "_".$orderType;
}
else if($v > 1000){
       echo "console.warn('force shuffle');\n";
       $orderType=-1;
}
else if($v%2==1){
       echo "console.warn('force last first');\n";
       $orderType=1;
}
else{
       echo "console.warn('force first first');\n";
       $orderType=0;
}

echo "let key ='".$version."';\n";
switch($orderType){
       default:
              echo "console.warn('shuffling');\n";
              echo "trialOrder.rearrange();\n";
       break;
       case 0:
              echo "console.warn('[0,1]');\n";
              echo "trialOrder.rearrange([0,1]);\n";
       break;
       case 1:
              echo "console.warn('[1,0]');\n";
              echo "trialOrder.rearrange([1,0]);\n";
       break;

}

?>



              const versionKey=trialOrder.getOrder()+key;



              //set up page and common values
              initCommonValues();

              document.getElementById('gameViewport').setAttribute('content',
                 'width=device-width initial-scale=' + 1/window.devicePixelRatio);

              function handleMouseDown(evt) {
                evt.preventDefault();
                evt.stopPropagation();
                evt.target.style.cursor = 'default';
                window.focus();
              }

              function handleMouseUp(evt) {
                evt.preventDefault();
                evt.stopPropagation();
                evt.target.style.cursor = '';
              }

              

              document.getElementById('embed-html').addEventListener('mousedown', handleMouseDown, false);
              document.getElementById('embed-html').addEventListener('mouseup', handleMouseUp, false);

              errorColor = getComputedStyle(document.body).getPropertyValue('--error-color');
       </script>
</html>
