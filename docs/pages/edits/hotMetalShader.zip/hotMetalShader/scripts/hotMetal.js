
/**
 * Call to produce  glsl code with window starting at the <code>lo</code> point
 * and <code>width</code> wide. Make sure your numbers are strings with decimal points in
 * them (eg. "1.0" not "1").
 * @param {*} type - the type of source image the shader should work for: can be z, f, or h.
 * <ul>
 *    <li> <code> z </code> - zeroed window (typically L:0 W:2000 HU)   </li>
 *    <li> <code> f </code> - full 8 bit window (L:1048 W:4096 HU)   </li>
 *    <li> <code> h </code> - high 16 bit window (high 8 bits are stored in red, low 8 bits stored in green)   </li>
 * </ul>
 * @param {*} lo - The low side of the window (don't confuse this with the level). This is in
 *                  viewer specific units where lo:0 = -1000HU, 0.5 = 0HU, 1 = 1000HU.
 *                  This should be a numeric string guarenteed to have a decimal point in it.
 * @param {*} width - The width of the window. This is in
 *                  viewer specific units where width:0 = 0HU, 0.5 = 1000HU, 1 = 2000HU.
 *                  This should be a numeric string guarenteed to have a decimal point in it.
 */
function hotMetalSpectrum(type,lo, width){
    if(type==undefined){
        console.error("You must specify a 'type': z, f, or h. Creating zeroed shader.");
        return hotMetalSpectrumShader1+"0.0"+hotMetalSpectrumShader2+"1.0"+hotMetalSpectrumShader3+"c.r"+hotMetalSpectrumShader4;
    }
    if(type=='z'){
        if(lo==undefined || width== undefined){
            console.warn("no window lo point and width specified, creating shader with lo:0.0(-1000HU) and width:1.0(2000HU).")
            return  hotMetalSpectrumShader1+"0.0"+hotMetalSpectrumShader2+"1.0"+hotMetalSpectrumShader3+"c.r"+hotMetalSpectrumShader4;
        }
        return hotMetalSpectrumShader1+lo+hotMetalSpectrumShader2+width+hotMetalSpectrumShader3+"c.r"+hotMetalSpectrumShader4;
    }
    if(type=='f'){
        if(lo==undefined || width== undefined){
            console.warn("no window lo point and width specified, creating shader with lo:0.0(-1000HU) and width:1.0(2000HU).")
            return  hotMetalSpectrumShader1+"0.0"+hotMetalSpectrumShader2+"1.0"+hotMetalSpectrumShader3+"O(c.r)"+hotMetalSpectrumShader4;
        }
        return hotMetalSpectrumShader1+lo+hotMetalSpectrumShader2+width+hotMetalSpectrumShader3+"O(c.r)"+hotMetalSpectrumShader4;
    }
    if(type=='h'){
        if(lo==undefined || width== undefined){
            console.warn("no window lo point and width specified, creating shader with lo:0.0(-1000HU) and width:1.0(2000HU).")
            return  hotMetalSpectrumShader1+"0.0"+hotMetalSpectrumShader2+"1.0"+hotMetalSpectrumShader3+"C(c.rg)"+hotMetalSpectrumShader4;
        }
        return hotMetalSpectrumShader1+lo+hotMetalSpectrumShader2+width+hotMetalSpectrumShader3+"C(c.rg)"+hotMetalSpectrumShader4;
    }
}


const hotMetalSpectrumShader1= "#ifdef GL_ES\n\
#define LOWP lowp\n\
    precision mediump float;\n\
#else\n\
    #define LOWP\n\
#endif\n\
varying LOWP vec4 v_color;\n\
varying vec2 v_texCoords;\n\
uniform sampler2D u_texture;\n\
\n\
float R(float c) {\n\
    return 1.4117556*c; \n\
}\n\
\n\
float G(float c) {\n\
    return 2.74*c-1.36541176471; \n\
}\n\
\n\
float B(float c) {\n\
    return 3.89285714284*c-2.92170868346; \n\
}\n\
\n\
vec3 h(float c) {\n\
    return vec3(R(c),G(c),B(c)); \n\
}\n\
\n\
float C(vec2 c) {\n\
    return (c.r*256.0+c.g)*0.1275; \n\
}\n\
\n\
float O(float c) {\n\
    return c*2.0475; \n\
}\n\
\n\
float W(float c) {\n\
    return (c-(";
    
const hotMetalSpectrumShader2="))/";
    
const hotMetalSpectrumShader3="; \n\
}\n\
\n\
void main()\n\
{\n\
    vec4 c = texture2D(u_texture, v_texCoords).rgba;\n\
    gl_FragColor = vec4(h(W(";
    
const hotMetalSpectrumShader4=")), c.a);\n\
}";

