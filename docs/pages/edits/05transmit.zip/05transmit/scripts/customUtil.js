console.log("found custom util");


let userClickedTrial2 = 0;
function addDiagBox(click){
    if(viewerGetCurrentSet()==2){
        userClickedTrial2++;
        let a=click.split(',');
        addInput(  "pTrial2"+click,
                        "pTrial2Diag",
                        "Diagnosis",
                        "pTrial2DiagElems",
                        "highlightClick("+a[0]+","+a[1]+", "+a[2]+", "+a[3]+", \""+currentShader+"\");useWASD=false;",
                        "",
                        "useWASD=true;");
        recheckTrial2();
    }
}
function removeDiagBox(click){
    if(viewerGetCurrentSet()==2){
        userClickedTrial2--;
        removeElement("pTrial2"+click);
        recheckTrial2();
    }
}

var userScrolled=false;
function scrollSuccess(){
    if(userScrolled)
        return;
    userScrolled=true;

    err(false,'pTrial1Scrl');
    err(false,'pTrial2Scrl');
}


function addInput(elemID, toID, hint="", className="", onfocus="", oninput="", onblur="") {
    let text = document.createElement('div');
    text.id = elemID;
    text.style.padding="2px";
    text.innerHTML = "<input type='text' style='width:90%;' class='"+className+"' placeholder='"+hint+"' onfocus='"+onfocus+"' onclick='"+onfocus+"' oninput='"+oninput+"' onblur='"+onblur+"'/>";

    $(toID).appendChild(text);
}

function addAll(at, key, valsClass){
    at=$(at);
    key=ID(key);
        
    let l=at.querySelectorAll('.'+valsClass);
    for(let i=0; i<l.length; ++i)
        addData(key+(i+1),l[i].value+" "+l[i].parentNode.id);
}

function removeElement(elemID){
    let e=$(elemID)
    e.parentNode.removeChild(e);
}

function highlightClick(at,x,y,z,shaderName=""){
    if(shaderName!=""){
        if(applyShader(shaderName))
            viewerLogShaderMessage("auto change to "+shaderName);
    }
    viewerResetHighlights(at);
    viewerAddHighlight(at,x,y,z);
    viewerLogScrollMessage(at,'auto scroll to '+z);
    viewerSetSlide(at,z);
}

function consentBranch(){
    if($('pConsentContinue1').checked){
        goToPage('pInstruction');
        silentClose(false);
        advanceCounter();
    }
    else if($('pConsentContinue2').checked)goToPage('pThanks');
}

let currentShader="off";
function applyShader(shaderName){
    if(currentShader==shaderName)
        return false;
    
    $('pTrial2Windowing').value=shaderName;
    viewerSetShader(shaderName);
    currentShader=shaderName;
}

function reward(){
    showViewerAt(4,0); //my reward page is at index 4, specified in slidedim.txt
    viewerClickLock(false);
    launchRandomFireworks(3,3,30,50,300,500,150,750,10,2,100,80,2000);
}