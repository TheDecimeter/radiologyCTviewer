class Trial{
    constructor(page, index, debrief, debriefMethod){
        this.page=page;
        this.index=index;
        this.debrief=debrief;
        this.debriefMethod=debriefMethod;

        this.startTime="unset";
        this.endTime="unset";
        this.duration="unset";
    }
    start(){
        console.log("starting "+this.page);
        this.startTime=viewerGetUpTime();
    }
    end(i, objName){
        console.log("ending "+this.page);
        this.endTime=viewerGetUpTime();
        this.duration=this.endTime-this.startTime;

        i++;
        $(this.page+"EndMessage").innerHTML= "you have completed trial "+i+" click the arrow to proceed";
        $("pDbfMsg"+i).innerHTML='Trial '+i+' '+this.debrief+' <button onclick="'+objName+'.debrief('+(i-1)+');" type="button">View</button>';

        applyShader("off");

        addData(this.page+"StartTime",this.startTime);
        addData(this.page+"EndTime",this.endTime);
        addData(this.page+"Duration",this.duration);
    }
}

class TrialOrder{
    constructor(lastPage, objName){
        this.i=0;
        this.lastPage=lastPage;
        this.objName=objName;

        this.order=[0,1];
        
        this.trials=[
            new Trial('pTrial1',1,"had 0 tumors",function(){
                cancelFireworks();
                goToPageWithViewer('pDbf1',1,1);
            }),
            new Trial('pTrial2',2,"had 3 tumors",function(){
                cancelFireworks();
                goToPageWithViewer('pDbf2',2,1);
            })
        ]
    }
    rearrange(newOrder){
        if(newOrder==undefined || newOrder.length==0)
            shuffle(this.order);
        else
            this.order=newOrder;
    }
    getTrial(i){
        return this.trials[this.order[i]];
    }
    startNext(){
        advanceCounter();
        let t=this.getTrial(this.i);
        goToPageWithViewer(t.page,t.index,1,function(){t.start();});
    }
    end(){
        this.getTrial(this.i).end(this.i,this.objName);
        this.i++;
        if(this.i==this.order.length){
            hideViewer();
            goToPage(this.lastPage);
            advanceCounter();
        }
    }
    debrief(i){
        this.getTrial(i).debriefMethod();
    }
    getOrder(){
        let r="";
        for(let i=0; i<this.order.length; ++i)
            r+=this.getTrial(i).page+";";
        return r;
    }
}