# fileName="m000-000001.asc"

import math
from PIL import Image
from os import walk

d=256
ascDir = "asc/" #input
pngDir = "png16/" #output




def convert(fileName):
    """
    convert from asc to png with values shared across both the red and green components
    This allows 8 bit images to have 16 bits of depth (if recombined with a shader later)

    fileName - the name of the file to convert, this function looks for the file in
        the directory specified by ascDir
    """
    newImg = []
    with open(ascDir+fileName) as f:
        for line in f:
            newImgLine=[]
            
            for p in line.split(" "):
                if len(p)==0:
                    continue
                if p=='\n':
                    continue
                n=int(p)
                hi=math.floor(n/d)
                lo=n-hi*d
                newImgLine.append((hi,lo,0)) #Set to put high bits in the R component, and low bits in the G component. B is ignored.
                
            if len(newImgLine)>0:
                newImg.append(newImgLine)
                
                
        f.close()


    res = (len(newImg[0]),len(newImg))
    fmt = "RGB"
    out = Image.new(fmt, res)
    data = out.load()

    for y in range(out.size[1]):
        for x in range(out.size[0]):
            data[x,y] = (newImg[y][x][0],newImg[y][x][1],newImg[y][x][2])

    tmpF=fileName.split(".")
    newF=tmpF[0]+".png"
    print("saving "+newF)

    out.save(pngDir+newF)

files = []
for (dirpath, dirnames, filenames) in walk(ascDir):
    files.extend(filenames)
    break

for f in files:
    convert(f)