import math
from PIL import Image
from os import walk

ascDir = "asc/" #input
pngDir = "png8/" #output

"""
You can set the "windowing" with the "hi" and "lo" below. Be aware though, this is not technically in HU.
Values range from 0 to typically 4095, HU ranges from -1000 and up.

So: -1000 in HU is 0 here (we don't use negative numbers so just offset your level by 1000).
hi = Level + Width/2
lo = Level - Width/2 

For "normal" shader use, it is recommended to use a high of 2000 and lo of 0.
For "full" shader use, set hi to 4095 and lo to 0 (not that this isn't technically full if 16 bit color depth is used, but 12 bit is common and wider ranges would a different shader)
"""
hi=2000
lo=0
rng=hi-lo




def convert(fileName):
    """
    convert from asc to png with the window specified in hi and lo above. This creates
    an 8 bit image so data will be lost. The default shaders (recommended) want lo = 0, hi = 2000
    (-1000 to 1000 HU). If using the "Full" shaders in the viewer use lo = 0, hi = 4095

    fileName - the name of the file to convert, this function looks for the file in
        the directory specified by ascDir so do not append the directory
    """
    newImg = []
    highest=0
    with open(ascDir+fileName) as f:
        for line in f:
            newImgLine=[]
            
            for p in line.split(" "):
                if len(p)==0:
                    continue
                if p=='\n':
                    continue
                n=float(p)
                highest=max(highest,n)
                if n>hi:
                    n=hi
                if n<lo:
                    n=lo
                n=math.floor(255*((n-lo)/rng))
                if n > 255:
                    print("n is > 255 "+str(n))
                newImgLine.append(n)
                
            if len(newImgLine)>0:
                newImg.append(newImgLine)
                
                
        f.close()


    res = (len(newImg[0]),len(newImg))
    fmt = "RGB"
    out = Image.new(fmt, res)
    data = out.load()

    for y in range(out.size[1]):
        for x in range(out.size[0]):
            data[x,y] = (newImg[y][x],newImg[y][x],newImg[y][x])

    tmpF=fileName.split(".")
    newF=tmpF[0]+".png"
    print("saving "+newF)

    out.save(pngDir+newF)
    return highest

# Go through every file in the directory (where you specified your ascii files were kept)
# and run them through the conversion function above.
files = []
for (dirpath, dirnames, filenames) in walk(ascDir):
    files.extend(filenames)
    break

highest=0
for f in files:
    highest=max(highest,convert(f))

print("Highest Value: "+str(highest))