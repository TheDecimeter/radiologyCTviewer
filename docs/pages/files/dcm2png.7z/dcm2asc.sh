#!/bin/bash

i=0
for f in *.dcm
do
    echo "converting $f"
    # medcon -f $f -c -b16 ascii

    OUTPUT=$(medcon -f $f) #get meta data so we can order our images

    #find the line in the data that talks about image position.
    while IFS=';' read -ra ADDR; do
        for t in "${ADDR[@]}"; do
            
            if [[ $t == *"ImagePositionPatient"* ]]; 
            then
                echo "full position: $t"

                SUBSTRING1=$(echo $t| cut -d':' -f 2)
                echo "position dimensions: $SUBSTRING1"

                SUBSTRING2=$(echo $SUBSTRING1| cut -d' ' -f 3) # order along the third or Z coordinate
                echo "key dimension: $SUBSTRING2"

                TRIMMED_SUBSTRING=$(echo -e "$SUBSTRING2" | tr -d '][')
                break;
            fi
        done
    done <<< "$OUTPUT"

    echo "trimmed $TRIMMED_SUBSTRING"

    #get the new filenames for what xMedCon renames it as, as well as a
    # name ordered by the axis we just found so that the images will
    # be ordered spatially.
    BASE_NAME=$(echo $f| cut -d'.' -f 1)
    CNV_NAME="m000-$BASE_NAME.asc"
    OFFSET_COORD=$(echo "10000000 * (2000 - ($TRIMMED_SUBSTRING + 1000))" | bc) #if somehow the values go below -1000, this would have to be increased
    ORD_NAME="asc/$OFFSET_COORD.asc"

    
    medcon -f $f -c -b16 ascii
    echo "converted name $CNV_NAME"
    echo "new name $ORD_NAME"
    mv $CNV_NAME $ORD_NAME

    # this is used for debugging if you want to only test the first few images.
    # ((i++))
    # if [[ "$i" -gt 3 ]]
    # then
    #     break
    # fi
done