#!/bin/bash
#This is for testing purposes only, it will make the images flicker because it readjusts the window
#dynamically for each image (but it'll churn out pngs faster than the python scripts).

for f in *.dcm
do
    echo "converting $f"
    medcon -f $f -c png
done
