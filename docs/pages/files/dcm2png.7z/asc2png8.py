import math
from PIL import Image
from os import walk

ascDir = "asc/" #input
pngDir = "png8/" #output

"""
You can set the "windowing" with the "hi" and "lo" below. Be aware though, this is not technically in HU.
Values range from 0 to typically 4095, HU ranges from -1000 and up.

So: -1000 in HU is 0 here (we don't use negative numbers so just offset your level by 1000).
hi = Level + Width/2
lo = Level - Width/2 

For "normal" shader use, it is recommended to use a high of 2000 and lo of 0.
For "full" shader use, set hi to 4095 and lo to 0 (not that this isn't technically full if 16 bit color depth is used, but 12 bit is common and wider ranges would a different shader)
"""
hi = 2000
lo = 0
rng = hi-lo

"""
It might be necessary to offset the values a bit. You can look in the metadata of the dicom image for this info
but if you used the included dcm2asc.sh, it will hopefully output this information for you:
 - (0028, 1054) type of unit, normally this tag is missing, which means the data is in HU. If this 
    field is present, and says something other than HU, this script probably won't work.
 - (0028,1052) intercept, this is what a value "0" is in HU (assuming the condition above is met.)
 - (0028,1053) slope, this is the rate of change between units, I've never seen it be anything other than 1.

If you want to keep the definition of values thinner than air, set your intercept to 1000 (but that would be slightly inaccurate)
"""
intercept = -1024
slope = 1

intercept += 1000 #no touchy


def convert(fileName):
    """
    convert from asc to png with the window specified in hi and lo above. This creates
    an 8 bit image so data will be lost. The default shaders (recommended) want lo = 0, hi = 2000
    (-1000 to 1000 HU). If using the "Full" shaders in the viewer use lo = 0, hi = 4095

    fileName - the name of the file to convert, this function looks for the file in
        the directory specified by ascDir so do not append the directory
    """
    newImg = []
    highest=0
    lessThanZero=0
    aboveHigh=0
    belowLow=0
    with open(ascDir+fileName) as f:
        for line in f:
            newImgLine=[]
            
            for p in line.split(" "):
                if len(p)==0:
                    continue
                if p=='\n':
                    continue
                n=float(p)
                n= n*slope + intercept
                highest=max(highest,n)
                if n>hi:
                    n=hi
                    aboveHigh += 1
                if n<lo:
                    if n<0:
                        lessThanZero += 1
                    n=lo
                    belowLow += 1

                n=math.floor(255*((n-lo)/rng))
                if n > 255:
                    print("n is > 255 "+str(n))
                newImgLine.append(n)
                
            if len(newImgLine)>0:
                newImg.append(newImgLine)
                
                
        f.close()


    res = (len(newImg[0]),len(newImg))
    fmt = "L"
    out = Image.new(fmt, res)
    data = out.load()

    for y in range(out.size[1]):
        for x in range(out.size[0]):
            data[x,y] = (newImg[y][x])

    tmpF=fileName.split(".")
    newF=tmpF[0]+".png"
    print("saving "+newF)

    out.save(pngDir+newF)
    return highest, aboveHigh, belowLow, lessThanZero, res[0]*res[1]

# Go through every file in the directory (where you specified your ascii files were kept)
# and run them through the conversion function above.
files = []
for (dirpath, dirnames, filenames) in walk(ascDir):
    files.extend(filenames)
    break

highest = 0
total = 0
aboveHigh = 0
belowLow = 0
belowZero = 0
for f in files:
    hiVal,abHi,belLo,bel0,tot = convert(f)
    highest=max(highest,hiVal)
    total += tot
    aboveHigh += abHi
    belowLow += belLo
    belowZero +=bel0


print("\n\nHighest Value: "+str(highest))
if total > 0:
    print("Percent In Window: "+str(((total-belowLow-aboveHigh)/total)*100))
    print("Percent Above Window: "+str((aboveHigh/total)*100))
    print("Percent Below Window: "+str((belowLow/total)*100))
    print("Percent Below Window that's \"air\": "+str((belowZero/total)*100))