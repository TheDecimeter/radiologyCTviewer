#!/bin/bash

#Make a folder called sort to put your new dicoms in
i=0
declare -a fileArray
for f in *.dcm
do
    echo "indexing $f"

    OUTPUT=$(medcon -f $f) #get meta data so we can order our images

    #find the line in the data that talks about image position.
    while IFS=';' read -ra ADDR; do
        for t in "${ADDR[@]}"; do
            
            if [[ $t == *"ImagePositionPatient"* ]]; 
            then
                echo "full position: $t"

                SUBSTRING1=$(echo $t| cut -d':' -f 2)
                echo "position dimensions: $SUBSTRING1"

                SUBSTRING2=$(echo $SUBSTRING1| cut -d' ' -f 3) # order along the third or Z coordinate
                echo "key dimension: $SUBSTRING2"

                TRIMMED_SUBSTRING=$(echo -e "$SUBSTRING2" | tr -d '][')
		break
            fi
        done
    done <<< "$OUTPUT"

    echo "trimmed $TRIMMED_SUBSTRING"

    #get the new filename based on the axis
    ORD_NAME="sort/$TRIMMED_SUBSTRING.dcm"

    fileArray[i]="$TRIMMED_SUBSTRING"
    
    echo "new name $ORD_NAME"
    cp $f $ORD_NAME
    ((i++))
    # this is used for debugging if you want to only test the first few images.
    #if [[ "$i" -gt 10 ]]
    #then
    #    break
    #fi
done


#go back through each file and rename it, otherwise some programs won't
#notice smaller numbers are meant to come first (if they start with a higher
#numberical value).
IFS=$'\n' sorted=($(sort -g -r <<<"${fileArray[*]}"))
unset IFS

i=1
for offset in "${sorted[@]}"
do
    if [[ "$i" -gt 999 ]]
    then
        newName="sort/$i.dcm"
    elif [[ "$i" -gt 99 ]]
    then
        newName="sort/0$i.dcm"
    elif [[ "$i" -gt 9 ]]
    then
        newName="sort/00$i.dcm"
    else
	newName="sort/000$i.dcm"
    fi

    ORD_NAME="sort/$offset.dcm"
    echo "renaiming $ORD_NAME to $newName"
    mv $ORD_NAME $newName
    ((i++))
done

