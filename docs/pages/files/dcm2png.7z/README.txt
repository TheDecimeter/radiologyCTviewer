These scripts turn a series of dicoms into pngs.

You will need:
- Linux, maybe, I know Windows uses bash now, but I've never tried it. I used Ubuntu
- XMedCon
- Python 3 (not needed if only sorting)


___ONLY SORT IMAGES____
Place these scripts in the folder with all of your dicom (.dcm) files.
Create a folder called "sort"

Run dcmSort.
$ ./dcmSort.sh

If this gives you trouble, make sure it has executable permissions.

The sort folder will now have copies of your dicoms ordered by z axis, you can now
open the folder in your preferred dicom viewer and export ordered dicoms.



___CONVERT DICOM IMAGES TO PNGs____
Place these scrips in the folder with all of your dicom (.dcm) files.
Open a terminal in the folder.

Create 2 folders called:
- asc
- png8 or png16 (depending on which python script you use, probably png8)

Run dcm2asc.
$ ./dcm2asc.sh

If this gives you trouble, make sure it has executable permissions.
This script will populate the asc folder with ascii files which are hopefully ordered spatially.

If dcm2asc.sh tells you that slopes or intercepts aren't consistant, or that units aren't in HU, these scripts might
not work (it will tell you this when it finishes).
If the slope and intercept printed when the dcm2asc.sh script finishes aren't [1] and [-1024] respectively, you will need to
change the slope and intercept in the python script used in the next step.


Run asc2png8 or asc2png16 depending on whether or not you intend on using 8 bit or 16 bit color depth (8 is recommended
unless you know exactly why you are wanting 16. If you're just wanting the biggest number, that's a bad reason. 

Be aware that if you are running asc2png8 you can set the windowing level of the image itself, the script comes set with L=0 and
W=2000, if you want something else, edit the script before running it.
$ python3 asc2png8       OR $ python3 asc2png16

You will now have pngs in their respective folder and they should be ordered spatially.


There might be one more final step if you use the 16 bit python script and imageMagick (not sure what exactly is going wrong). The
image will probably be dark when a shader is applied to it in the viewer, to fix this, simply open the image in Gimp and resave it.



Troubleshooting:

If the pngs aren't in the correct order check the output
when you ran dcm2asc.sh, it should have said something like this:

 converting 000420.dcm
 full position: (0020,0032) DS[3] ImagePositionPatient: [-166.000000] [-180.000000] [-49.369999] (34 bytes)
 position dimensions:  [-166.000000] [-180.000000] [-49.369999] (34 bytes)
 key dimension: [-49.369999]
 trimmed -49.369999
 converted name m000-000420.asc
 new name asc/m000-49.369999.asc

Notice how the "full position" (second line) has 3 coordinates, and the following lines strip away the z component.
This is how it orders the files. Look at the other files, the x and y should stay the same and z should change, if this
isn't the case, edit the dcm2asc.sh file at line 22. You'll see that it is stripping away the third (z) component, instead
change the '3' to a '1' or '2' for x or y respectively (depending on which coordinate is changing).
You may also want to check line 38 which offsets negative numbers and assumes nothing goes below 1000, while also removing
zeros (and assuming nothing goes past 7 decimal places)



If the asc file never gets filled, it is probably because xmedcon is naming the files something unexpected. In dcm2asc.sh
at line 37 there is a format for what it expects xmedcon to name the file (it expects it to start with "m000-". If for some
reason this changed the folder with .dcms will be filled with asc files, look at the way the file name is structured and 
edit lines 36 and 37 to match.


You can uncomment lines 48 - 52 if you want to only output the first 4 files for debugging purposes (so you don't have to wait for
an entire series to complete.
