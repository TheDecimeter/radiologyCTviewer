#Rename dicom files so that they will be ordered spatially.

#Note that this renames files, so you might want to make a backup of your dicoms
# to run this script on.

#This script requires pydicom, https://pydicom.github.io/pydicom/stable/tutorials/installation.html
#if you are in Linux and xmedcon already use sortdcm.sh, that file requires no other dependencies.

#This is based off of ColonelFazackerley on Stack Overflow
#https://stackoverflow.com/questions/59458801/how-to-sort-dicom-slices-in-correct-order


import pydicom
import numpy
import os

filelocs = []
for (dirpath, dirnames, filenames) in os.walk(os.getcwd()):
    filelocs.extend(filenames)
    break


files=[]
for f in filelocs:
    if ".dcm" in f:
        files.append((pydicom.dcmread(f),f))

print("file count: {}".format(len(files)))

# skip files with no SliceLocation (eg scout views)
slices = []
for f in files:
    if hasattr(f[0], 'SliceLocation'):
        slices.append(f)

# ensure they are in the correct order
slices = sorted(slices, key=lambda s: -s[0].SliceLocation)

usableSlices=[]
unitMessage="No units found, assume HU (Good)"
for f in slices:
    if hasattr(f[0], 'RescaleSlope') and hasattr(f[0], 'RescaleIntercept'):
        usableSlices.append(f)
    else:
        print("no slope or intercept: "+f[1])
    if hasattr(f[0], 'RescaleType'):
        unitMessage="Rescale Type found (it better be HU): "+f[0].RescaleType

print("usable files: {}".format(len(usableSlices)))
print(unitMessage)

intercept=usableSlices[0][0].RescaleIntercept
slope=usableSlices[0][0].RescaleSlope

allGood=True
for f in usableSlices:
    if f[0].RescaleIntercept != intercept:
        allGood=False
    if f[0].RescaleSlope != slope:
        allGood=False




def dicom2asc(dycom, fileName):
    try:
        numpy.savetxt(os.path.join("asc",fileName), dycom.pixel_array.astype(int), delimiter=' ', fmt="%-1.1d")
        print("Saving "+fileName)
    except:
        print('Could not convert: ', fileName)

i=0
for s in usableSlices:
    i += 1
    if i > 999:
       dicom2asc(s[0],str(i)+".asc")
    elif i > 99:
        dicom2asc(s[0],"0"+str(i)+".asc")
    elif i > 9:
        dicom2asc(s[0],"00"+str(i)+".asc")
    else:
        dicom2asc(s[0],"000"+str(i)+".asc")

print("\n")
print(unitMessage)
if allGood:
    print("Slope and Intercept are consistant (Good).\nSlope: {}, Intercept: {}".format(slope,intercept))
else:
    print("The slope and or intercept wasn't consistant, this means these files might not be usable.")