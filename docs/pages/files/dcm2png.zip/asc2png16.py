# fileName="m000-000001.asc"

import math
from PIL import Image
from os import walk

d=256
ascDir = "asc/" #input
pngDir = "png16/" #output

"""
It might be necessary to offset the values a bit. You can look in the metadata of the dicom image for this info
but if you used the included dcm2asc.sh, it will hopefully output this information for you:
 - (0028, 1054) type of unit, normally this tag is missing, which means the data is in HU. If this 
    field is present, and says something other than HU, this script probably won't work.
 - (0028,1052) intercept, this is what a value "0" is in HU (assuming the condition above is met.)
 - (0028,1053) slope, this is the rate of change between units, I've never seen it be anything other than 1.

If you want to keep the definition of values thinner than air, set your intercept to 1000 (but that would be slightly inaccurate)
"""
intercept = -1024
slope = 1

intercept += 1000 #no touchy



def convert(fileName):
    """
    convert from asc to png with values shared across both the red and green components
    This allows 8 bit images to have 16 bits of depth (if recombined with a shader later)

    fileName - the name of the file to convert, this function looks for the file in
        the directory specified by ascDir
    """
    newImg = []
    with open(ascDir+fileName) as f:
        for line in f:
            newImgLine=[]
            
            for p in line.split(" "):
                if len(p)==0:
                    continue
                if p=='\n':
                    continue
                n=int(p)
                n= math.floor(n*slope + intercept)
                if n < 0:
                    n=0
                if n > 65535:
                    n=65535
                hi=math.floor(n/d)
                lo=n-hi*d
                newImgLine.append((hi,lo,0)) #Set to put high bits in the R component, and low bits in the G component. B is ignored.
                
            if len(newImgLine)>0:
                newImg.append(newImgLine)
                
                
        f.close()


    res = (len(newImg[0]),len(newImg))
    fmt = "RGB"
    out = Image.new(fmt, res)
    data = out.load()

    for y in range(out.size[1]):
        for x in range(out.size[0]):
            data[x,y] = (newImg[y][x][0],newImg[y][x][1],newImg[y][x][2])

    tmpF=fileName.split(".")
    newF=tmpF[0]+".png"
    print("saving "+newF)

    out.save(pngDir+newF)

files = []
for (dirpath, dirnames, filenames) in walk(ascDir):
    files.extend(filenames)
    break

for f in files:
    convert(f)