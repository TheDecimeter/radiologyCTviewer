#Rename dicom files so that they will be ordered spatially.

#Note that this renames files, so you might want to make a backup of your dicoms
# to run this script on.

#This script requires pydicom, https://pydicom.github.io/pydicom/stable/tutorials/installation.html
#if you are in Linux and xmedcon already use sortdcm.sh, that file requires no other dependencies.

#This is based off of ColonelFazackerley on Stack Overflow
#https://stackoverflow.com/questions/59458801/how-to-sort-dicom-slices-in-correct-order


import pydicom
import os

filelocs = []
for (dirpath, dirnames, filenames) in os.walk(os.getcwd()):
    filelocs.extend(filenames)
    break


files=[]
for f in filelocs:
    if ".dcm" in f:
        files.append((pydicom.dcmread(f),f))

print("file count: {}".format(len(files)))

# skip files with no SliceLocation (eg scout views)
slices = []
skipcount = 0
for f in files:
    if hasattr(f[0], 'SliceLocation'):
        slices.append(f)
    else:
        skipcount = skipcount + 1

print("skipped, no SliceLocation: {}".format(skipcount))

# ensure they are in the correct order
slices = sorted(slices, key=lambda s: -s[0].SliceLocation)


i=0
for s in slices:
    i += 1
    if i > 999:
        os.rename(s[1],"sorted_"+str(i)+".dcm")
    elif i > 99:
        os.rename(s[1],"sorted_0"+str(i)+".dcm")
    elif i > 9:
        os.rename(s[1],"sorted_00"+str(i)+".dcm")
    else:
        os.rename(s[1],"sorted_000"+str(i)+".dcm")