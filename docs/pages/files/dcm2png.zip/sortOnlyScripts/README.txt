These files only sort dicoms spatially so that you can run them through your preferred dicom reader
and have them export in order.

sortdcm.py can be run in Windows if you have the pydicom module installed
  This file renames the current dicoms

sortdcm.sh can be run in Linux if you have medcon installed
  This file makes a copy of the current dicoms in the "sort" folder