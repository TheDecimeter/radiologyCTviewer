#!/bin/bash

i=0
units="No Units Specified, assume HU (good)"
slope="Unknown"
slopeCons="All Slopes are Consistant (good)"
intercept="Unknown"
interceptCons="All Intercepts are Consistant (good)"

declare -a fileArray

for f in *.dcm
do
    echo "converting $f"
    # medcon -f $f -c -b16 ascii

    OUTPUT=$(medcon -f $f) #get meta data so we can order our images

    #find the line in the data that talks about image position.
    #and the lines about slope, intercept, and units
    while IFS=';' read -ra ADDR; do
        for t in "${ADDR[@]}"; do
            
            if [[ $t == *"ImagePositionPatient"* ]]; 
            then
                echo "full position: $t"

                SUBSTRING1=$(echo $t| cut -d':' -f 2)
                echo "position dimensions: $SUBSTRING1"

                SUBSTRING2=$(echo $SUBSTRING1| cut -d' ' -f 3) # order along the third or Z coordinate
                echo "key dimension: $SUBSTRING2"

                TRIMMED_SUBSTRING=$(echo -e "$SUBSTRING2" | tr -d '][')
            fi

            if [[ $t == *"(0028,1054)"* ]]; 
            then
                units="$t"
            fi

            if [[ $t == *"(0028,1053)"* ]]; 
            then
                if [[ $t != "$slope" ]]&&[[ $slope != "Unknown" ]];
                then
                    echo "                  INCONSISTANT slopes! $t"
                    slopeCons="    Inconsistant slopes (going to be hard to convert)"
                fi
                slope="$t"
            fi

            if [[ $t == *"(0028,1052)"* ]]; 
            then
                if [[ $t != "$intercept"  ]]&&[[ $intercept != "Unknown" ]];
                then
                    echo "                  INCONSISTANT intercepts! $t"
                    interceptCons="    Inconsistant intercepts (going to be hard to convert)"
                fi
                intercept="$t"
            fi
        done
    done <<< "$OUTPUT"

    echo "trimmed $TRIMMED_SUBSTRING"

    #get the new filenames for what xMedCon renames it as, as well as a
    # name ordered by the axis we just found so that the images will
    # be ordered spatially.
    BASE_NAME=$(echo $f| cut -d'.' -f 1)
    CNV_NAME="m000-$BASE_NAME.asc"
    ORD_NAME="asc/$TRIMMED_SUBSTRING.asc"

    fileArray[i]="$TRIMMED_SUBSTRING"
    
    medcon -f $f -b16 -c ascii
    echo "converted name $CNV_NAME"
    echo "new name $ORD_NAME"
    mv $CNV_NAME $ORD_NAME
    ((i++))

    # this is used for debugging if you want to only test the first few images.
    #if [[ "$i" -gt 3 ]]
    #then
    #    break
    #fi
done




#go back through each file and rename it, otherwise some programs won't
#notice smaller numbers are meant to come first (if they start with a higher
#numberical value).
IFS=$'\n' sorted=($(sort -g -r <<<"${fileArray[*]}"))
unset IFS

i=1
for offset in "${sorted[@]}"
do
    if [[ "$i" -gt 999 ]]
    then
        newName="asc/$i.asc"
    elif [[ "$i" -gt 99 ]]
    then
        newName="asc/0$i.asc"
    elif [[ "$i" -gt 9 ]]
    then
        newName="asc/00$i.asc"
    else
	newName="asc/000$i.asc"
    fi

    ORD_NAME="asc/$offset.asc"
    echo "renaiming $ORD_NAME to $newName"
    mv $ORD_NAME $newName
    ((i++))
done




echo ""
echo ""
echo "$slopeCons"
echo "$interceptCons"
echo ""
echo "Units: $units"
echo "Slope (final value in brackets, probably '[1]'): $slope"
echo "Intercept (final value in brackets, probably '[-1024]'): $intercept"
