___Included Scripts____

 - For sorting and converting dicoms to ascii files.
   - dcm2asc.sh (Requires: Linux, and xmedcon)
   - dcm2asc.py (Requires: pydicom, and numpy)

 - For converting ascii files to png
   - asc2png8.py (Requires: pillow)
   - asc2png16.py (Requires: pillow)

 - For pre sorting dicoms for use in another dicom exporter
   - sortOnlyScripts/sortdcm.py (Requires: pydicom)
   - sortOnlyScripts/sortdcm.sh (Requires: Linux, and xmedcon)

 - For debugging
   - debugScript/dcm2png.sh (Requires: Linux, and xmedcon)
     This file quickly turns dicoms into pngs, but with dynamic windows, good
     for seeing the layout of dicoms in a folder, bad for anything else.


___Requirements____

 - Python's pillow (https://pypi.org/project/Pillow/2.2.1/#installation)
   - if using asc2png8.py or asc2png16.py

 - Python's pydicom (https://pydicom.github.io/pydicom/stable/tutorials/installation.html)
   - if using dcm2asc.py or sortdcm.py

 - Python's numpy (https://numpy.org/install/)
   - if using dcm2asc.py

 - xmedcon (https://xmedcon.sourceforge.io/Main/Download) (in Ubuntu: $ sudo apt-get install xmedcon)
   - if using dcm2asc.sh, sortdcm.sh, or dcm2png.sh



########################################################################
########### Convert dicom to png #######################################

Extract the contents of this archive directly in with the dicom images
 (so that the scripts and dicoms (.dcm) are in the same folder together)

Run dcm2asc:
 $ dcm2asc.sh
     or
 $ python3 dcm2asc.py

This will fill the asc folder with ascii files (note that the bash script makes ascii files with 0s in the corner,
 whereas python fills them with -1024s, for the remaining steps, both formats are fine).

Look at the console output, you should see: units, slope, and intercept.
 Make sure units were HU (or unspecified), if they aren't these scripts probably won't work.

Open the script used in the next step in a text editor. 

Set the hi and lo values to the bounds of your perferred window (These bounds are measured 
 in HU + 1000, so Air is 0, not -1000). Note, only asc2png8.py has windowing.

Make sure the slope and intercept equal the values printed to the console. If they aren't
 change them.

Save the script when finished.

Run asc2png:
 $ python3 asc2png8.py
    ADVANCED: Use asc2png16.py if converting to simulated 16 bit PNGs. Be aware that these images
               will have to be reconstructed in the viewer to be usable.

Your images will now be in the png8 folder.
    ADVANCED: If you used asc2png16.py, the images will be in the png16 folder



########################################################################
########### Sort dicoms to be extracted with another program ###########

Pull the sort scripts out of their folder and place them with the dicoms.
 (so that the scripts and dicoms (.dcm) are in the same folder together)

Run sortdcm:
 $ sortdcm.sh
     or
 $ python3 sortdcm.py

The bash script will fill the sort folder with new files, the python script will rename
  the current files.
